% Ryan Lindsay 101038101

x = 3;  %Dimensions 
y = 2;


dx = 0.1;
dy = 0.1;

nx = x/dx;
ny = y/dy;

% Create matrix 
G = sparse(nx*ny, nx*ny);
F = zeros(nx*ny,1);


%% Part A 

for i = 1:nx
    for j = 1:ny 
        
        n = i + (j-1)*nx;
        nxp = (i+1) + (j-1)*nx;
        nxm = (i-1) + (j-1)*nx;
        nym = i + (j-2)*nx;
        nyp = i + (j*nx);
        
        if i ==1 || i ==nx
            G(n,n) =1;
            F(n) = 1;
            
        elseif j == 1 || j ==ny
            G(n,n) =1;
            
        else
            G(n,n) = -4;
            G(n,nxm) = 1;
            G(n,nxp) = 1;
            G(n,nym) = 1;
            G(n, nyp) = 1;
        end
    end
end

Vmat = zeros(nx,ny);
Ex = zeros(nx,ny);
Ey = zeros(nx,ny);
V = G\F;

for i = 1:nx
    for j = 1:ny
        
        n = i + (j-1)*nx;
        
        Vmat(i,j) = V(n);
        
        
    end
end

for i = 1:nx
    for j = 1:ny
        if i ==1
            Ex(i,j) = Vmat(i+1,j) - Vmat(i,j);
        elseif i ==nx
            Ex(i,j) = Vmat(i,j) - Vmat(i-1,j);
        else 
            Ex(i,j) = (Vmat(i+1,j) - Vmat(i-1,j))*0.5;
        end
        if j ==1 
            Ey(i,j) = Vmat(i, j+1) - Vmat(i,j);
        elseif j == ny
            Ey(i,j) = Vmat(i,j) - Vmat(i,j-1);
        else
            Ey(i,j) = (Vmat(i, j+1) - Vmat(i, j-1))*0.5;
        end
    end
end

figure(1) 
surf(Ex)
title('E-Field Ex')
xlabel('Y Direction')
ylabel('X Direction')
zlabel('Voltage')

figure(2) 
surf(Ey)
title('E-Field Ey')
xlabel('Y Direction')
ylabel('X Direction')
zlabel('Voltage')

        
% Sigma Matrix 


sigma = ones(nx,ny);


% Change value of sigma to 10^-2 for bottleneck
for i = 1:nx
    for j =1:ny
        
        if j <= ny/3 || j>= 2*ny/3
            
            if i >= nx/3 && i<= 2*nx/3
                
                sigma(i,j) = 10^-2;
                
            end
        end
    end
end



Efield = sqrt(Ex.^2 + Ey.^2);


Jf = sigma.*Efield;


figure(3)
mesh(sigma)
title('Sigma Plot')
xlabel('Y Direction')
ylabel('X Direction')
zlabel('Sigma')

figure(4)
surf(Jf)
title('Current Density')
xlabel('Y Direction')
ylabel('X Direction')
zlabel('Current')






%% Part B 

% Reset variables 
Efield = 0;
Jf = 0;
sigma = 0;

% Establish variables for Current 
Cur = 0;
sumCur = 0;
prevCur = 0;

% Recreate G and F matrix
G = sparse(nx*ny,nx*ny);
F = zeros(nx*ny,1);





for i = 1:nx
    for j = 1:ny 
        
        n = i + (j-1)*nx;
        nxp = (i+1) + (j-1)*nx;
        nxm = (i-1) + (j-1)*nx;
        nym = i + (j-2)*nx;
        nyp = i + (j*nx);
        
        if i ==1 || i ==nx
            
            G(n,n) =1;
            F(n) = 1;
            
        elseif j == 1 || j ==ny
            
            G(n,n) =1;
            
            
        else
            
            G(n,n) = -4;
            G(n,nxm) = 1;
            G(n,nxp) = 1;
            G(n,nym) = 1;
            G(n, nyp) = 1;
            
            
        end
    end
end


Vmat = zeros(nx,ny);

Ex = zeros(nx,ny);
Ey = zeros(nx,ny);

V = G\F;

for Mesh = 1:1:10
for i = 1:nx
    for j = 1:ny
        
        n = i + (j-1)*nx;
        
        Vmat(i,j) = V(n);
    end
end
for i = 1:nx
    for j = 1:ny
        if i ==1
            Ex(i,j) = Vmat(i+1,j) - Vmat(i,j);
        elseif i ==nx
            Ex(i,j) = Vmat(i,j) - Vmat(i-1,j);
        else 
            Ex(i,j) = (Vmat(i+1,j) - Vmat(i-1,j))*0.5;
        end
        if j ==1 
            Ey(i,j) = Vmat(i, j+1) - Vmat(i,j);
            
            
        elseif j == ny
            Ey(i,j) = Vmat(i,j) - Vmat(i,j-1);
        else
            Ey(i,j) = (Vmat(i, j+1) - Vmat(i, j-1))*0.5;
        end
    end
end

sigma = ones(nx,ny);

for i = 1:nx
    for j =1:ny
        
        if j <= ny/3 || j>= 2*ny/3
            
            if i >= nx/3 && i<= 2*nx/3
                
                sigma(i,j) = 10^-2;
                
            end
        end
    end
end

Efield = sqrt(Ex.^2 + Ey.^2);
Jf = sigma.*Efield;

prevCur = Cur;
Cur = sum(Jf, 'All');

figure(5)
plot([Mesh-1 Mesh], [prevCur Cur], 'b')
hold on 
title ('Mesh Size vs Current')
xlabel('Mesh Size')
ylabel('Current')

end




%% Part C 

% Create multiple instances of sigma 
sigma1 = ones(nx,ny);
sigma2 = ones(nx,ny);
sigma3 = ones(nx,ny);
sigma4 = ones(nx,ny);
sigma5 = ones(nx,ny);

% Adjust the boundaries of the various sigmas 
for i=1:nx 
    
    % Original Sigma
    for j =1:ny
        if j <= ny/3 || j>= 2*ny/3
            if i >= nx/3 && i<= 2*nx/3
                sigma1(i,j) = 10^-2;
            end
        end
        
     % Sigma 2 Lengthen X barrier 
     if j <= ny/3 || j>= 2*ny/3
         if i >= nx/8 && i<= 7*nx/8
             sigma2(i,j) = 10^-2;
         end
     end
     
     % Sigma 3 Shorten X barrier 
     
     if j<= ny/3 || j>= 2*ny/3
         if i > 7*nx/16 && i <= 9*nx/16
             sigma3(i,j) = 10^-2;        
         end
     end
     
     % Sigma 4 Lengthen Y barrier 
     if j<=ny/8 || j>= 7*ny/8
         if i>= nx/3  && i <= 2*nx/3
             sigma4(i,j) = 10^-2;
         end 
     end
     
     % Sigma 5 Shorten Y Barrier 
     if j<=7*ny/16 || j>= 9*ny/16    
         if i>= nx/3  && i <= 2*nx/3
             sigma5(i,j) = 10^-2;
         end
     end
    end
end


% Repeating previous code from Part A 

 for i = 1:nx
    for j = 1:ny 
        
        n = i + (j-1)*nx;
        nxp = (i+1) + (j-1)*nx;
        nxm = (i-1) + (j-1)*nx;
        nym = i + (j-2)*nx;
        nyp = i + (j*nx);
        
        if i ==1 || i ==nx;
            
            G(n,n) =1;
            F(n) = 1;
            
        elseif j == 1 || j ==ny
            
            G(n,n) =1;
            
            
        else
            
            G(n,n) = -4;
            G(n,nxm) = 1;
            G(n,nxp) = 1;
            G(n,nym) = 1;
            G(n, nyp) = 1;
            
            
        end
    end
end

    
Vmat = zeros(nx,ny);

Ex = zeros(nx,ny);
Ey = zeros(nx,ny);

V = G\F;


for i = 1:nx
    for j = 1:ny
        
        n = i + (j-1)*nx;
        
        Vmat(i,j) = V(n);
        
        
    end
end



for i = 1:nx
    for j = 1:ny
        if i ==1
            Ex(i,j) = Vmat(i+1,j) - Vmat(i,j);
            
            
        elseif i ==nx
            Ex(i,j) = Vmat(i,j) - Vmat(i-1,j);
            
        else 
            Ex(i,j) = (Vmat(i+1,j) - Vmat(i-1,j))*0.5;
            
            
        end
        
        
        if j ==1 
            Ey(i,j) = Vmat(i, j+1) - Vmat(i,j);
            
            
        elseif j == ny
            Ey(i,j) = Vmat(i,j) - Vmat(i,j-1);
            
            
        else
            Ey(i,j) = (Vmat(i, j+1) - Vmat(i, j-1))*0.5;
            
            
        end
    end
end


Efield = sqrt(Ex.^2 + Ey.^2);

J1 = sigma1.*Efield;
J2 = sigma2.*Efield;
J3 = sigma3.*Efield;
J4 = sigma4.*Efield;
J5 = sigma5.*Efield;


figure(6)
mesh(sigma1)
title('Original Sigma')
xlabel('Y Direction')
ylabel('X Direction')

figure(7)
mesh(sigma2)
title('Sigma 1')
xlabel('Y Direction')
ylabel('X Direction')

figure(8)
mesh(sigma3)
title('Sigma 2')
xlabel('Y Direction')
ylabel('X Direction')

figure(9)
mesh(sigma4)
title('Sigma 3')
xlabel('Y Direction')
ylabel('X Direction')

figure(10)
mesh(sigma5)
title('Sigma 4')
xlabel('Y Direction')
ylabel('X Direction')



sumJ1=sum(J1,'All');
sumJ2=sum(J2,'All');
sumJ3=sum(J3,'All');
sumJ4=sum(J4,'All');
sumJ5=sum(J5,'All');
Jtot=[sumJ1 sumJ2 sumJ3 sumJ4 sumJ5];
Sigmatot=[sigma1 sigma2 sigma3 sigma4 sigma5];


figure(11)
plot([1 2 3 4 5], Jtot)
xticks([1 2 3 4 5])
xlabel('Sigma')
ylabel('Current')
title('Current vs Sigma #')




%% Part D 

G = sparse(nx*ny, nx*ny);
F = zeros(nx*ny,1);

Jprev = 0;
Jsum = 0;
% Loop through values of sigma 

for sig = 10^-2: 0.01 : 0.5



for i = 1:nx
    for j = 1:ny 
        
        n = i + (j-1)*nx;
        nxp = (i+1) + (j-1)*nx;
        nxm = (i-1) + (j-1)*nx;
        nym = i + (j-2)*nx;
        nyp = i + (j*nx);
        
        if i ==1 || i ==nx;
            
            G(n,n) =1;
            F(n) = 1;
            
        elseif j == 1 || j ==ny
            
            G(n,n) =1;
            
            
        else
            
            G(n,n) = -4;
            G(n,nxm) = 1;
            G(n,nxp) = 1;
            G(n,nym) = 1;
            G(n, nyp) = 1;
            
            
        end
    end
end

Vmat = zeros(nx,ny);

Ex = zeros(nx,ny);
Ey = zeros(nx,ny);

V = G\F;


for i = 1:nx
    for j = 1:ny
        
        n = i + (j-1)*nx;
        
        Vmat(i,j) = V(n);
        
        
    end
end



for i = 1:nx
    for j = 1:ny
        if i ==1
            Ex(i,j) = Vmat(i+1,j) - Vmat(i,j);
            
            
        elseif i ==nx
            Ex(i,j) = Vmat(i,j) - Vmat(i-1,j);
            
        else 
            Ex(i,j) = (Vmat(i+1,j) - Vmat(i-1,j))*0.5;
            
            
        end
        
        
        if j ==1 
            Ey(i,j) = Vmat(i, j+1) - Vmat(i,j);
            
            
        elseif j == ny
            Ey(i,j) = Vmat(i,j) - Vmat(i,j-1);
            
            
        else
            Ey(i,j) = (Vmat(i, j+1) - Vmat(i, j-1))*0.5;
            
            
        end
    end
end



sigma = ones(nx,ny);



for i = 1:nx
    for j =1:ny
        
        if j <= ny/3 || j>= 2*ny/3
            
            if i >= nx/3 && i<= 2*nx/3
                
                sigma(i,j) = sig;
                
            end
        end
    end
end

Jprev = Jsum;

Efield = sqrt(Ex.^2 + Ey.^2);

Jtot = sigma .*Efield;

Jsum = sum(Jtot,'All');

figure(12)
hold on
plot(sig,Jsum,'rx')
title('Current vs Sigma')
xlabel('Sigma')
ylabel('Current')







end
hold off
