% Ryan Lindsay 101038101

x = 3;   
y = 2;


dx = 0.1;
dy = 0.1;

nx = x/dx;
ny = y/dy;

% Create matrix 
G = sparse(nx*ny, nx*ny);
F = zeros(nx*ny,1);

%% Part A


for i = 1:nx
    for j = 1:ny
        n = ny * (i - 1) + j;
        if i == 1
            G(n,n) = 1;
            F(n) = 1;
            
        elseif i == nx
            G(n,n) = 1;
            
        elseif j == 1
            G(n,n) = -3;
            G(n, n+1) = 1;
            G(n, n+ny) = 1;
            G(n, n-ny) = 1;
            
        elseif j == ny 
            
            G(n,n) = -3;
            G(n, n-1) = 1;
            G(n, n+ny) = 1;
            G(n, n-ny) = 1;
            
        else
            G(n,n) = -4;
            G(n, n+1) = 1;
            G(n, n-1) = 1;
            G(n, n+ny) = 1;
            G(n, n-ny) = 1;
        end
    end
end
V = G\F;
Vmat = zeros(nx,ny,1);

for i = 1:nx
    for j =1:ny
        n = j+(i-1)*ny;
        Vmat(i,j) = V(n);
        
    end
end


figure(1)
surf(Vmat)
title('Voltage Plot')
xlabel('Y Direction')
ylabel('X Direction')
zlabel('Voltage')




%% Part B 

G = sparse(nx*ny,nx*ny);      
F = zeros(nx*ny,1);


for i = 1:nx
    for j = 1:ny 
        
        n = i + (j-1)*nx;
        nxp = (i+1) + (j-1)*nx;
        nxm = (i-1) + (j-1)*nx;
        nym = i + (j-2)*nx;
        nyp = i + (j*nx);
        
        if i ==1 || i ==nx
            
            G(n,n) =1;
            F(n) = 1;
            
        elseif j == 1 || j ==ny
            
            G(n,n) =1;
            
        else
            
            G(n,n) = -4;
            G(n,nxm) = 1;
            G(n,nxp) = 1;
            G(n,nym) = 1;
            G(n, nyp) = 1;
            F(n) = 0;
            
        end
    end
end

Vmat2 = zeros(nx,ny);
V = G\F;

for i =1:nx
    for j = 1:ny
        n = i + (j-1)*nx;
        Vmat2(i,j) = V(n);
        
    end
end




figure(2)
surf(Vmat2)
title('Numerical Solution')
xlabel('Y Direction')
ylabel('X Direction')



sum = 0;

for i = 1:nx
    for j = 1:ny
        for n = 1:2:(nx*ny)
            
            sum = sum + ((1/n) * cosh(n*pi*i/dx) * sin(n*pi*j/dx)) / cosh(n*pi*dy/dx);
            
        end
        
    end
    
    Vmat2 (i,j) = 4*sum/pi;
    
end



figure(3) 
surf(Vmat2)
title('Analytical Solution')
xlabel('Y Direction')
ylabel('X Direction')





            
            

            

        
        
        
        
        
        
        

        
     

            
            
            
            
            
            


